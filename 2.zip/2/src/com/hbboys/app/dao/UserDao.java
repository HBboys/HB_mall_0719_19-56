package com.hbboys.app.dao;

import com.hbboys.app.domain.User;

public interface UserDao {
	public void register(User user);
	
	public void update(User user);
}

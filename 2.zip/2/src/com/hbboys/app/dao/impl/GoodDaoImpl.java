package com.hbboys.app.dao.impl;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.hbboys.app.dao.GoodDao;
import com.hbboys.app.domain.Good;
import com.hbboys.app.domain.User;

public class GoodDaoImpl extends HibernateDaoSupport implements GoodDao{

	@Override
	public void newgood(Good good) {
		// TODO Auto-generated method stub
		this.getHibernateTemplate().save(good);
	}

	@Override
	public void deletegood(int gid) {
		// TODO Auto-generated method stub
		this.getHibernateTemplate().delete(this.findbyid(gid));
	}

	@Override
	public void editgood(Good good) {
		// TODO Auto-generated method stub
		this.getHibernateTemplate().update(good);
	}

	@Override
	public List<Good> myallgood(int currentPage,int pageSize) {
		// TODO Auto-generated method stub
		@SuppressWarnings("unchecked")
		List<Good> list = this.getHibernateTemplate().executeFind(new HibernateCallback<Object>() {
			public Object doInHibernate(Session session) throws HibernateException,SQLException {
				HttpSession session2=ServletActionContext.getRequest().getSession();
				
				
				User user=(User) session2.getAttribute("user");
				Query query  = session.createQuery("from Good where sellerid=?");
				query.setInteger(0, user.getUid());
				query.setFirstResult((currentPage-1)*pageSize);
				query.setMaxResults(pageSize);
				List<Good> list = query.list();
				return list;
			}
		});
		return list;
	}

	@Override
	public Good findbyid(int gid) {
		// TODO Auto-generated method stub
		return this.getHibernateTemplate().get(Good.class, gid);
	}

	@Override
	public int mygoodcount() {
		// TODO Auto-generated method stub
		@SuppressWarnings("unchecked")
		List<Long> list = this.getHibernateTemplate().executeFind(new HibernateCallback<Object>() {
			public Object doInHibernate(Session session) throws HibernateException,SQLException {
				HttpSession session2=ServletActionContext.getRequest().getSession();
				User user=(User) session2.getAttribute("user");
				Query query  = session.createQuery("select count(*) from Good where sellerid=?");
				query.setInteger(0, user.getUid());
				List<Long> list = query.list();
				return list;
			}
		});
		return list.get(0).intValue();
//		@SuppressWarnings("unchecked")
//		List<Long> list=this.getHibernateTemplate().find("select count(*) from Good");
//		Long count=list.listIterator().next();
//		return count.intValue();
	}

	@Override
	public List<Good> filtergood(int currentPage, int pageSize) {
		// TODO Auto-generated method stub
		@SuppressWarnings("unchecked")
		List<Good> list = this.getHibernateTemplate().executeFind(new HibernateCallback<Object>() {
			public Object doInHibernate(Session session) throws HibernateException,SQLException {
				HttpSession session2=ServletActionContext.getRequest().getSession();
				String querystr=(String) session2.getAttribute("querystr");
				Query query  = session.createQuery("from Good ?");
				query.setString(0, querystr);
				query.setFirstResult((currentPage-1)*pageSize);
				query.setMaxResults(pageSize);
				List<Good> list = query.list();
				return list;
			}
		});
		return list;
	}

	@Override
	public List<Good> findallgood(int currentPage, int pageSize) {
		@SuppressWarnings("unchecked")
		List<Good> list = this.getHibernateTemplate().executeFind(new HibernateCallback<Object>() {
			public Object doInHibernate(Session session) throws HibernateException,SQLException {
				Query query  = session.createQuery("from Good");
				query.setFirstResult((currentPage-1)*pageSize);
				query.setMaxResults(pageSize);
				List<Good> list = query.list();
				return list;
			}
		});
		return list;
	}

	@Override
	public int allgoodcount() {
		@SuppressWarnings("unchecked")
		List<Long> list = this.getHibernateTemplate().executeFind(new HibernateCallback<Object>() {
			public Object doInHibernate(Session session) throws HibernateException,SQLException {
				Query query  = session.createQuery("select count(*) from Good");
				List<Long> list = query.list();
				return list;
			}
		});
		return list.get(0).intValue();
	}

}

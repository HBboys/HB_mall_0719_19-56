package com.hbboys.app.action;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.hbboys.app.domain.Good;
import com.hbboys.app.domain.Order;
import com.hbboys.app.domain.User;
import com.hbboys.app.service.GoodService;
import com.hbboys.app.service.OrderService;
import com.hbboys.app.util.HibernateUtil;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

public class OrderAction extends ActionSupport implements ModelDriven<Order>{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Order order=new Order();
	private OrderService orderService;
	private int currentPage=1;
	private int pageSize=5;
	public Date currenttime;
	private String gid;
	private String uid;
	public String getGid() {
		return gid;
	}

	public void setGid(String gid) {
		this.gid = gid;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public Date getCurrenttime() {
		Date currenttime=new Date();
		return currenttime;
	}

	public void setCurrenttime(Date currenttime) {
		order.setTime(currenttime);
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public OrderService getOrderService() {
		return orderService;
	}

	public void setOrderService(OrderService orderService) {
		this.orderService = orderService;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}
	
	public String makeorder() {
		// TODO Auto-generated method stub

		HttpSession session2=ServletActionContext.getRequest().getSession();
		User buyer=(User) session2.getAttribute("user");
		Good good=(Good) session2.getAttribute("good");
		float buyermoney=Float.parseFloat(buyer.getMoney());
		int goodprice=good.getPrice();
		int goodcount=good.getCount();
		HttpServletRequest request=ServletActionContext.getRequest();
		order.setUser(buyer);
		order.setGood(good);
//		request.setAttribute("ordererror", "");
		if(goodcount>0) {
					if(buyermoney>goodprice) {
						orderService.makeorder(order);
						return "success";
					}else {
						request.setAttribute("ordererror", "�������㣡");
						return "fail";
					}
				}else {				
					request.setAttribute("ordererror", "��Ʒ�������㣡");
					return "fail";
				}
	}

	public String cancelorder() {
		orderService.cancelorder(order.getOrderid());
		return "success";
	}
	
	public String addcomment() {
		orderService.addcomment(order.getCommenttext());
		return SUCCESS;
	}
	
	@Override
	public Order getModel() {
		// TODO Auto-generated method stub
		return order;
	}
	
}

package com.hbboys.app.dao.impl;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.hbboys.app.dao.OrderDao;
import com.hbboys.app.domain.Good;
import com.hbboys.app.domain.Order;
import com.hbboys.app.domain.User;

public class OrderDaoImpl extends HibernateDaoSupport implements OrderDao{

	@Override
	public void makeorder(Order order) {
		// TODO Auto-generated method stub
		User buyer=order.getUser();
		Good good=order.getGood();
		float buyermoney=Float.parseFloat(buyer.getMoney());
		User seller=order.getGood().getUser();
		float sellermoney=Float.parseFloat(seller.getMoney());
		int goodprice=order.getGood().getPrice();
		int goodcount=order.getGood().getCount();
		if(goodcount>0) {
			if(buyermoney>goodprice) {
				buyer.setMoney(Float.toString(buyermoney-goodprice));
				seller.setMoney(Float.toString(sellermoney+goodprice));
				good.setCount(goodcount);
				this.getHibernateTemplate().update(buyer);
				this.getHibernateTemplate().update(seller);
				this.getHibernateTemplate().update(good);
			}
		}
		this.getHibernateTemplate().save(order);
	}

	@Override
	public void cancelorder(int orderid) {
		// TODO Auto-generated method stub
		this.getHibernateTemplate().delete(this.findbyid(orderid));
	}

	@Override
	public List<Order> myallorder(int currentPage, int pageSize) {
		// TODO Auto-generated method stub
		@SuppressWarnings("unchecked")
		List<Order> list = this.getHibernateTemplate().executeFind(new HibernateCallback<Object>() {
			public Object doInHibernate(Session session) throws HibernateException,SQLException {
				HttpSession session2=ServletActionContext.getRequest().getSession();
				int uid=(int) session2.getAttribute("uid");
				Query query  = session.createQuery("from Order where buyerid=?");
				query.setInteger(0, uid);
				query.setFirstResult((currentPage-1)*pageSize);
				query.setMaxResults(pageSize);
				List<Order> list = query.list();
				return list;
			}
		});
		return list;
	}

	@Override
	public Order findbyid(int orderid) {
		// TODO Auto-generated method stub
		return this.getHibernateTemplate().get(Order.class, orderid);
	}

	@Override
	public int myordercount() {
		// TODO Auto-generated method stub
		@SuppressWarnings("unchecked")
		List<Object> list = this.getHibernateTemplate().executeFind(new HibernateCallback<Object>() {
			public Object doInHibernate(Session session) throws HibernateException,SQLException {
				HttpSession session2=ServletActionContext.getRequest().getSession();
				int uid=(int) session2.getAttribute("uid");
				Query query  = session.createQuery("from Order where buyerid=?");
				query.setInteger(0, uid);
				List<Object> list = query.list();
				return list;
			}
		});
		Long count=(Long) list.listIterator().next();
		return count.intValue();
	}

	@Override
	public boolean canmakeorder(Order order) {
		// TODO Auto-generated method stub
		User buyer=order.getUser();		
		float buyermoney=Float.parseFloat(buyer.getMoney());
		
		int goodprice=order.getGood().getPrice();
		int goodcount=order.getGood().getCount();
		HttpSession session=ServletActionContext.getRequest().getSession();
		if(goodcount>0) {
			if(buyermoney>goodprice) {
				return true;
			}else {
				session.setAttribute("ordererror", "�������㣡");
				return false;
			}
		}else {				
			session.setAttribute("ordererror", "��Ʒ�������㣡");
			return false;
		}
	}
}

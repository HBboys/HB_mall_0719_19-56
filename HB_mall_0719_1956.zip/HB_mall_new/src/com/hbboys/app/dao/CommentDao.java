package com.hbboys.app.dao;

import java.util.List;

import com.hbboys.app.domain.Comment;

public interface CommentDao {
	
	public void newcomment(Comment comment);
	
	public void deletecomment(int orderid);
	
	public List<Comment> myallcomment(int currentPage,int pageSize); 
	
	public Comment findbyid(int orderid);
	
	public int mycommentcount();
}

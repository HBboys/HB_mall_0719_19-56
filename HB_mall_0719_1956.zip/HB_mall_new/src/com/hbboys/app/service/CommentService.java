package com.hbboys.app.service;

import com.hbboys.app.domain.Comment;
import com.hbboys.app.vo.CommentPage;

public interface CommentService {
	
	public void newcomment(Comment comment);
	
	public void deletecomment(int orderid);
	
	public CommentPage myallcomment(int currentPage,int pageSize); 
}
